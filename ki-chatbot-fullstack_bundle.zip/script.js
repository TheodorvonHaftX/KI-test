const messagesDiv = document.getElementById('messages');
const webglDiv = document.getElementById('webgl');

// Chat logic
function addMessage(text, sender='bot') {
  const div = document.createElement('div');
  div.className = 'message ' + sender;
  div.textContent = text;
  messagesDiv.appendChild(div);
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

async function sendMessage() {
  const input = document.getElementById('userInput');
  const msg = input.value.trim();
  if (!msg) return;
  addMessage(msg, 'user');
  input.value = '';
  const enableSearch = document.getElementById('autoSearch').checked;
  const enableCode = document.getElementById('enableCode').checked;
  const improve = document.getElementById('selfImprove').checked;
  addMessage('🧠 KI denkt...', 'bot');
  // Simulate API call
  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ message: msg, enableSearch, enableCode, improve })
  }).then(res => res.json());
  addMessage(response.reply, 'bot');
}

// Three.js WebGL setup
let scene, camera, renderer, cube;
function initWebGL() {
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(75, webglDiv.clientWidth/webglDiv.clientHeight, 0.1, 1000);
  renderer = new THREE.WebGLRenderer();
  renderer.setSize(webglDiv.clientWidth, webglDiv.clientHeight);
  webglDiv.appendChild(renderer.domElement);
  const geometry = new THREE.BoxGeometry();
  const material = new THREE.MeshNormalMaterial();
  cube = new THREE.Mesh(geometry, material);
  scene.add(cube);
  camera.position.z = 5;
  animate();
}
function animate() {
  requestAnimationFrame(animate);
  cube.rotation.x += 0.01;
  cube.rotation.y += 0.01;
  renderer.render(scene, camera);
}
window.addEventListener('load', initWebGL);
