const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
app.use(bodyParser.json());
app.use(express.static(__dirname));
app.post('/api/chat', async (req, res) => {
  const { message, enableSearch, enableCode, improve } = req.body;
  // Hier Integration zu deinem AI-Backend oder OpenAI-API
  let reply = '🗣️ Antwort auf: ' + message;
  if (enableCode && message.toLowerCase().includes('html')) {
    reply = '💻 Generierter HTML-Code wurde erstellt.';
  } else if (improve && message.includes('verbessere')) {
    reply = '📈 Selbstverbesserung durchgeführt.';
  } else if (enableSearch) {
    reply = '🔍 Web-Suche-Ergebnisse für "'+message+'" hinzugefügt.';
  }
  res.json({ reply });
});
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Server läuft auf Port', PORT));
